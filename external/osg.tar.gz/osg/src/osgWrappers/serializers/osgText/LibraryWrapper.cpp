#include <osgDB/Registry>

USE_SERIALIZER_WRAPPER(osgText_FadeText)
USE_SERIALIZER_WRAPPER(osgText_Text)
USE_SERIALIZER_WRAPPER(osgText_Text3D)
USE_SERIALIZER_WRAPPER(osgText_TextBase)

extern "C" void wrapper_serializer_library_osgText(void) {}

