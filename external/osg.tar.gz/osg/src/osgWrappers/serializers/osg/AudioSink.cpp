#include <osg/AudioStream>
#include <osgDB/ObjectWrapper>
#include <osgDB/InputStream>
#include <osgDB/OutputStream>

REGISTER_OBJECT_WRAPPER( AudioSink,
                         /*new osg::AudioSink*/NULL,
                         osg::AudioSink,
                         "osg::Object osg::AudioSink" )
{
}
