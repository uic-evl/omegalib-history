#include <osgSim/Sector>
#include <osgDB/ObjectWrapper>
#include <osgDB/InputStream>
#include <osgDB/OutputStream>

REGISTER_OBJECT_WRAPPER( osgSim_Sector,
                         /*new osgSim::Sector*/NULL,
                         osgSim::Sector,
                         "osg::Object osgSim::Sector" )
{
}
