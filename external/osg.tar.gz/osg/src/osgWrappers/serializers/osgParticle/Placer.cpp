#include <osgParticle/Placer>
#include <osgDB/ObjectWrapper>
#include <osgDB/InputStream>
#include <osgDB/OutputStream>

REGISTER_OBJECT_WRAPPER( osgParticlePlacer,
                         /*new osgParticle::Placer*/NULL,
                         osgParticle::Placer,
                         "osg::Object osgParticle::Placer" )
{
}
